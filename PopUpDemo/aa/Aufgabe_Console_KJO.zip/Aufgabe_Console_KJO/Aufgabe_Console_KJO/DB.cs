﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Aufgabe_Console_KJO
{
    internal class DB
    {
        //public DB(string connString)
        //{
        //    using (OleDbConnection connection = new OleDbConnection(connString))
        //    {
        //        string query = String.Format("SELECT * FROM {0}",);
        //        OleDbCommand command = new OleDbCommand(query, connection);
        //        // Öffnen der Verbindung
        //        connection.Open();

        //        DataTable userTables = connection.GetSchema("Tables");

        //        foreach (DataRow row in userTables.Rows)
        //        {
        //            string tableName = (string)row["TABLE_NAME"];
        //            Tables.Add(new Table(row));
        //        }
        //    }
        //}
        public List<Table> Tables = new List<Table>();
    }
}
