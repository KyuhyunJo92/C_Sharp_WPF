﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aufgabe_Console_KJO
{
    internal class Column_IndexElement
    {
        public Column_IndexElement(string ordinal_position, string column_name) 
        {
            _ordinal_position = ordinal_position;
            _column_name = column_name;
        }
        public string _ordinal_position {  get; set; }
        public string _column_name { get; set; }
    }
}
