﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Remoting.Messaging;
using System.Collections;
using System.Net.Http.Headers;
using System.Xml.Linq;
using System.Net;
using System.Security.Policy;

namespace Aufgabe_Console_KJO
{
    internal class AccessToDatenbank
    {
        public AccessToDatenbank(string connectionString)
        {
            _connectionString = connectionString;
        }
        string _connectionString { get; set; }
        public List<Table> MakeModel()
        {
            var tables = new List<Table>();

            using (OleDbConnection connection = new OleDbConnection(_connectionString))
            {
                connection.Open();

                DataTable schemaTable = connection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });

                foreach (DataRow row in schemaTable.Rows)
                {
                    var table = new Table();
                    table.Name = row["TABLE_NAME"].ToString();
                    //table.primaryKey = row[""]

                    DataTable columnTable = connection.GetOleDbSchemaTable(OleDbSchemaGuid.Columns, new object[] { null, null, table.Name, null });

                    foreach (DataRow columnRow in columnTable.Rows)
                    {
                        var field = new Field
                        {
                            Name = columnRow["COLUMN_NAME"].ToString(),

                            DataType = columnRow["DATA_TYPE"].ToString(),

                            FieldLength = columnRow["CHARACTER_MAXIMUM_LENGTH"].ToString(),

                            Posiition = int.Parse(columnRow["ORDINAL_POSITION"].ToString()),

                            Nullablity = bool.Parse(columnRow["IS_NULLABLE"].ToString()),

                            DefaultVal = columnRow["COLUMN_DEFAULT"].ToString()
                        };

                        table.Fields.Add(field);
                    }
                    tables.Add(table);
                }
            }
            return tables;
        }

        public void WriteTableCSV(List<Table> tables)
        {
            string csvPath = "C:\\Users\\GastUser\\Desktop\\Table.csv";

            using (StreamWriter writer = new StreamWriter(csvPath, false, Encoding.Default))
            {
                foreach (Table t in tables)
                {
                    writer.WriteLine(t.Name);
                }
            }
        }

        public void WriteFieldCSV(List<Table> tables)
        {
            string csvPath = "C:\\Users\\GastUser\\Desktop\\Field.csv";

            using (StreamWriter writer = new StreamWriter(csvPath))
            {
                foreach (Table t in tables)
                {
                    foreach (Field f in t.Fields)//.OrderBy(f => f.Name))//.Where(f => f.DataType == "7"))
                    {
                        string fieldData = String.Format("{0},{1},{2},{3},{4},{5}", f.Name, f.DataType, f.FieldLength, f.Posiition, f.DefaultVal, f.Nullablity);
                        writer.WriteLine(fieldData);
                    }
                }
            }
        }

        public void HolenNummerSieben(List<Table> tables)
        {
            string csvPath = "C:\\Users\\GastUser\\Desktop\\NummerSieben.csv";

            using (StreamWriter writer = new StreamWriter(csvPath))
            {
                foreach (Table t in tables)
                {
                    foreach (Field f in t.Fields)
                    {
                        if (f.DataType == "7")
                        {
                            string fieldData = String.Format("{0};{1};{2};{3};{4};{5}", f.Name, f.DataType, f.FieldLength, f.Posiition, f.DefaultVal, f.Nullablity);
                            writer.WriteLine(fieldData);
                        }
                    }
                }
            }
        }
        public void GetAllIndex()
        {
            List<Index> indexes = new List<Index>();

            using (OleDbConnection conn = new OleDbConnection(_connectionString))
            {
                conn.Open();

                // Get the datatable containing the schema information on indexes
                DataTable indexSchema = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Indexes, null);

                List<Column_IndexElement> columns = new List<Column_IndexElement>();

                string previousTableName = String.Empty;
                string previousIndexName = String.Empty;
                foreach (DataRow row in indexSchema.AsEnumerable().OrderBy(r => r["TABLE_NAME"]).ThenBy(r => r["INDEX_NAME"]))
                {
                    string currentTableName = row["TABLE_NAME"].ToString();
                    string currentIndexName = row["INDEX_NAME"].ToString();

                    if (currentTableName != previousTableName ||
                        currentIndexName != previousIndexName)
                    {
                        indexes.Add(new Index(previousTableName, previousIndexName, columns));
                    }

                    columns.Add(new Column_IndexElement(row["ORDINAL_POSITION"].ToString(), row["COLUMN_NAME"].ToString()));
                    
                    previousTableName = currentTableName;
                    previousIndexName = currentIndexName;
                    
                    
                    //if (currentTableName != previousTableName)
                    //{
                    //    columns.Add(new Column_IndexElement(row["ORDINAL_POSITION"].ToString(), row["COLUMN_NAME"].ToString()));
                    //}
                    ////Index ix = new Index(row["TABLE_NAME"].ToString(), row["INDEX_NAME"].ToString());
                    //else
                    //{
                    //    indexes.Add(new Index(row["TABLE_NAME"].ToString(), row["INDEX_NAME"].ToString(), columns));

                    //    //clear
                    //    columns = new List<Column_IndexElement>();
                    //    previousTableName = row["TABLE_NAME"].ToString();
                    //}
                }
            }
            //using (OleDbConnection connection = new OleDbConnection(connectionString))
            //{
            //    connection.Open();

            //    // Get all Index Information from DB 
            //    DataTable indexSchema = connection.GetOleDbSchemaTable(OleDbSchemaGuid.Indexes, null);

            //    // Write the Information to CSV File
            //    foreach (DataRow row in indexSchema.Rows)
            //    {
            //        string indexName = row["INDEX_NAME"].ToString();

            //        List<string> columns = new List<string>();

            //        if(columns.)

            //        string ordinalPosition = row["ORDINAL_POSITION"].ToString();


            //        columns.Add(ordinalPosition);


            //        indexes.Add(new Index(row["TABLE_NAME"].ToString(), row["INDEX_NAME"].ToString(),columns));
            //    }                      
            //}
        }
        //private List<Table> GetTableList() 
        //{
        //    List<Table> Tables = new List<Table>();

        //    using (OleDbConnection connection = new OleDbConnection(_connectionString))
        //    {
        //        // Öffnen der Verbindung
        //        connection.Open();

        //        DataTable userTables = connection.GetSchema("Tables");

        //        foreach (DataRow row in userTables.Rows)
        //        {
        //            string tableName = (string)row["TABLE_NAME"];
        //            //Tables.Add(new Table(connection, tableName));
        //        }
        //    }
        //    return Tables;
        //}
        //public void tableNameToCSV(List<Table> tables)
        //{
        //    using (StreamWriter writer = new StreamWriter("C:\\Users\\GastUser\\Desktop\\tableNames.csv"))
        //    {
        //        foreach (Table el in tables)
        //        {
        //            writer.WriteLine(el.Name);
        //        }
        //    }

        //}
        //private void fieldsToCSV(string connString)
        //{
        //    //tName, 
        //    using (StreamWriter writer = new StreamWriter("C:\\Users\\GastUser\\Desktop\\fields.csv"))
        //    {

        //    }
        //}
        //private void TableNames(string connString)
        //{
        //    using (OleDbConnection connection = new OleDbConnection(connString))
        //    {
        //        // Öffnen der Verbindung
        //        connection.Open();

        //        DataTable userTables = connection.GetSchema("Tables");

        //        using (StreamWriter writer = new StreamWriter("C:\\Users\\GastUser\\Desktop\\tableNames.csv"))
        //        {

        //            foreach (DataRow row in userTables.Rows)
        //            {
        //                string tableName = (string)row["TABLE_NAME"];
        //                writer.WriteLine(tableName);
        //            }
        //        }
        //    }
        //}
        //private void Fields(string connString)
        //{
        //    using (OleDbConnection connection = new OleDbConnection(connString))
        //    {
        //        // Öffnen der Verbindung
        //        connection.Open();

        //        DataTable userTables = connection.GetSchema("Tables");

        //        {
        //            foreach (DataRow row in userTables.Rows)
        //            {
        //                string tableName = (string)row["TABLE_NAME"];
        //                Field(connString, tableName);
        //            }
        //        }
        //    }
        //}

        //private void Fields(string connString, string tableName)
        //{
        //    StringBuilder csvContent = new StringBuilder();

        //    // Überschriften schreiben
        //    csvContent.AppendLine("Feld;Datentyp;Feldlänge;Position;Standardwert");

        //    using (OleDbConnection connection = new OleDbConnection(connString))
        //    {
        //        // Öffnen der Verbindung
        //        connection.Open();

        //        DataTable userTables = connection.GetSchema("Tables");
        //        foreach (DataRow row in userTables.Rows)
        //        {
        //            string query = $"SELECT * FROM {tableName}";

        //            using (OleDbCommand command = new OleDbCommand(query, connection))
        //            {
        //                using (OleDbDataReader reader = command.ExecuteReader())
        //                {
        //                    string csvPath_ = String.Format($"C:\\Users\\GastUser\\Desktop\\{0}_{1}.csv", tableName);
        //                    using (StreamWriter writer = new StreamWriter(csvPath_))
        //                    {
        //                        // Tabelle Schema (Metadaten) bekommen 
        //                        DataTable schemaTable = connection.GetOleDbSchemaTable(
        //                        OleDbSchemaGuid.Columns,
        //                        new Object[] { null, null, tableName });

        //                        // Daten schreiben
        //                        foreach (DataRow elRow in schemaTable.Rows)
        //                        {
        //                            for (int i = 0; i < 3; i++)
        //                            {
        //                                csvContent.Append(row[i].ToString().Replace(";", ","));

        //                                if (i < reader.FieldCount - 1)
        //                                    csvContent.Append(";");
        //                            }
        //                            csvContent.AppendLine();
        //                        }
        //                        // CSV-Datei schreiben
        //                        //File.WriteAllText(csvPath, csvContent.ToString());

        //                    }
        //                }
        //            }
        //        }


        //    }
        //}

        //private void Field(string connString, string tableName)
        //{
        //    //string connString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\\temp\\mydatabase.mdb";
        //    //string tableName = "myTable";
        //    ,tableName);
        //    //string csvPath = "C:\\Users\\GastUser\\Desktop\\Field.csv";

        //    using (StreamWriter writer = new StreamWriter(csvPath))
        //    {
        //        using (OleDbConnection connection = new OleDbConnection(connString))
        //        {
        //            connection.Open();

        //            string query = $"SELECT * FROM {tableName}";

        //            using (OleDbCommand command = new OleDbCommand(query, connection))
        //            {
        //                using (OleDbDataReader reader = command.ExecuteReader())
        //                {
        //                    StringBuilder csvContent = new StringBuilder();

        //                    // Spaltenüberschriften schreiben
        //                    for (int i = 0; i < reader.FieldCount; i++)
        //                    {
        //                        csvContent.Append(reader.GetName(i));
        //                        if (i < reader.FieldCount - 1)
        //                            csvContent.Append(";");
        //                    }
        //                    csvContent.AppendLine();

        //                    // Daten schreiben
        //                    while (reader.Read())
        //                    {
        //                        for (int i = 0; i < reader.FieldCount; i++)
        //                        {
        //                            csvContent.Append(reader[i].ToString().Replace(";", ","));
        //                            if (i < reader.FieldCount - 1)
        //                                csvContent.Append(";");
        //                        }
        //                        csvContent.AppendLine();
        //                    }

        //                    // CSV-Datei schreiben
        //                    writer.WriteLine(csvContent.ToString());
        //                }
        //            }
        //        }
        //    }
        //}
    }
}
