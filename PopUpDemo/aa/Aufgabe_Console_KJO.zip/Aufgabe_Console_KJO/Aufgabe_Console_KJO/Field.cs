﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aufgabe_Console_KJO
{
    internal class Field
    {
        public string Name {  get; set; }
        public string DataType { get; set; }/* { CHAR, VARCHAR, TEXT, INT, SMALLINT, DECIMAL, FLOAT, DATE, TIME, DATETIME, BINARY, VARBINARY, BLOB, BOOLEAN ,BOOL };*/
        public string FieldLength { get; set; }
        public string DefaultVal { get; set; }

        public int Posiition { get; set; }
        public bool Nullablity = true;

        //public Field(DataRow dataRow)
        //{

        //}
    }
}

/*DataTable schemaTable = connection.GetOleDbSchemaTable(
            OleDbSchemaGuid.Columns,
            new Object[] { null, null, tableName, null });

            foreach (DataRow row in schemaTable.Rows)
            {
                string columnName = row["COLUMN_NAME"].ToString();
                Console.WriteLine(columnName);
            }*/
