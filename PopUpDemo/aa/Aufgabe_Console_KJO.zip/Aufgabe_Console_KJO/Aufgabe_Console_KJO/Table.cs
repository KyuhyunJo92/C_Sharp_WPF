﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aufgabe_Console_KJO
{
    internal class Table
    {
        public string Name { get; set; }

        public string primaryKey { get; set; }
        //public Table(DataRow row)
        //{
        //    Name = row.Table.TableName;

        //    //Fields = getFields(connection, TableName);
        //}
        public List<Field> Fields = new List<Field>();

        //private List<Field> getFields(OleDbConnection connection, string TableName)
        //{
        //    List<Field> fields = new List<Field>();
            
        //    DataTable userTables = connection.GetSchema("Tables");
                
        //    foreach (DataRow row in userTables.Rows)
        //    {
        //        fields.Add(new Field(row));
        //    }
        //    return fields;
        //}
    }
}
