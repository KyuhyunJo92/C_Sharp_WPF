﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
using System.Data;
using System.Dynamic;
using System.Net;

namespace Aufgabe_Console_KJO
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string connectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\\Users\\GastUser\\Desktop\\dpf.mdb";
            string IndexesCSVPath = @"C:\\Users\\GastUser\\Desktop\\Indexes.csv";
            AccessToDatenbank ATD = new AccessToDatenbank(connectionString);
            List<Table> tables = ATD.MakeModel();

            //ATD.ConnectToAccess(connectionString);
            ATD.WriteTableCSV(ATD.MakeModel());
            //ATD.GetAllIndex(connectionString);
            ATD.WriteFieldCSV(ATD.MakeModel()); 
            ATD.HolenNummerSieben(ATD.MakeModel());

            ATD.GetAllIndex();

            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }
    }
}
