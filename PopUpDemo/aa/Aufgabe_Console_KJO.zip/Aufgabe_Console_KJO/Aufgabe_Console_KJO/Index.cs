﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aufgabe_Console_KJO
{
    internal class Index
    {
        //constructor
        public Index(string tableName, string indexName, List<Column_IndexElement> columns)
        {
            _tableName=tableName;
            _indexName=indexName;
            _columns=columns;
        }

        public Index() { }

        public void setColumns(List<Column_IndexElement> c)
        {
            _columns = c;
        }

        //properties
        public string _tableName;
        public string _indexName;
        public List<Column_IndexElement> _columns = new List<Column_IndexElement>();
    }
}
