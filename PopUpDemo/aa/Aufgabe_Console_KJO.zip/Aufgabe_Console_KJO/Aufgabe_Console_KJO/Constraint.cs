﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aufgabe_Console_KJO
{
    internal class Constraint
    {
        public string ConstraintName { get; set; }
        public string TableName { get; set; }
        public List<Field> Fields { get; set; }
    }
}
